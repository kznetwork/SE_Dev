"""Gemini CLI 훅 입력을 받아 세션별 실행 기록과 대화 원본을 보관합니다."""

from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import re
import sys
from uuid import uuid4


def sanitize_filename(name: str) -> str:
    """Windows 및 파일 시스템에서 안전한 파일명으로 변환합니다."""
    sanitized = re.sub(r'[\\/*?:"<>|\r\n\t]+', "_", name)
    sanitized = re.sub(r"__+", "_", sanitized).strip("._ ")
    return sanitized or "대화세션"


def extract_topic_from_transcript(payload: dict) -> str:
    """대화 내용 또는 프롬프트에서 대표 주제어를 추출합니다."""
    transcript_path = payload.get("transcript_path")
    user_texts: list[str] = []

    if transcript_path and Path(transcript_path).exists():
        try:
            for line in Path(transcript_path).read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    data = json.loads(line)
                except Exception:
                    continue
                if isinstance(data, dict) and data.get("type") == "user":
                    for item in data.get("content", []):
                        if isinstance(item, dict) and "text" in item:
                            text = item["text"]
                            clean = re.sub(r"<session_context>[\s\S]*?</session_context>", "", text).strip()
                            if clean and clean.lower() not in {"go", "yes", "no", "y", "n", "ok", "done", "계속", "진행"}:
                                user_texts.append(clean)
        except Exception:
            pass

    if not user_texts and payload.get("prompt"):
        clean = re.sub(r"<session_context>[\s\S]*?</session_context>", "", payload["prompt"]).strip()
        if clean and clean.lower() not in {"go", "yes", "no", "y", "n", "ok", "done", "계속", "진행"}:
            user_texts.append(clean)

    if not user_texts:
        return "대화세션"

    first_text = user_texts[0]
    if "배송비" in first_text and ("계산" in first_text or "TDD" in first_text or "TC" in first_text or "계약" in first_text):
        return "배송비_계산_TDD"
    if "배송비" in first_text:
        return "배송비_계산"
    if "세션 로그" in first_text and "Transcript" in first_text:
        return "세션로그_Transcript_저장_수정"

    words = re.findall(r"[가-힣a-zA-Z0-9]+", first_text)
    if words:
        candidate = "_".join(words[:4])
        return candidate[:30]

    return "대화세션"


def get_session_md_path(payload: dict, root: Path, session_folder: Path) -> Path:
    """세션에 할당된 docs/Prompt/NN.주제어-날짜.md 경로를 반환합니다."""
    map_file = session_folder / "transcript_md_path.txt"
    if map_file.exists():
        rel_path = map_file.read_text(encoding="utf-8").strip()
        if rel_path:
            full_path = root / rel_path
            if full_path.exists() or full_path.parent.exists():
                return full_path

    prompt_dir = root / "docs" / "Prompt"
    prompt_dir.mkdir(parents=True, exist_ok=True)

    existing_nums: list[int] = []
    for file in prompt_dir.glob("*.md"):
        m = re.match(r"^(\d+)\.", file.name)
        if m:
            existing_nums.append(int(m.group(1)))
    next_num = max(existing_nums, default=0) + 1
    nn_str = f"{next_num:02d}"

    topic = None
    topic_file = session_folder / "topic.txt"
    if topic_file.exists():
        t = topic_file.read_text(encoding="utf-8").strip()
        if t:
            topic = t

    if not topic:
        topic = extract_topic_from_transcript(payload)

    date_str = datetime.now().strftime("%Y%m%d")
    safe_topic = sanitize_filename(topic)
    filename = f"{nn_str}.{safe_topic}-{date_str}.md"
    md_path = prompt_dir / filename

    map_file.write_text(str(md_path.relative_to(root)).replace("\\", "/"), encoding="utf-8")
    return md_path


def render_transcript_markdown(
    transcript_path_str: str | None,
    session_id: str,
    title: str,
    fallback_prompt: str = "",
    fallback_response: str = "",
) -> str:
    """대화 내용을 읽기 쉬운 Markdown 형식으로 변환합니다."""
    turns: list[tuple[str, str]] = []
    current_gemini: list[str] = []

    if transcript_path_str and Path(transcript_path_str).exists():
        try:
            content_str = Path(transcript_path_str).read_text(encoding="utf-8")
            lines = [line for line in content_str.splitlines() if line.strip()]
            for line in lines:
                try:
                    data = json.loads(line)
                except Exception:
                    continue
                if not isinstance(data, dict):
                    continue
                mtype = data.get("type")
                if mtype == "user":
                    for item in data.get("content", []):
                        if isinstance(item, dict) and "text" in item:
                            text = item["text"]
                            clean = re.sub(r"<session_context>[\s\S]*?</session_context>", "", text).strip()
                            if clean:
                                if current_gemini:
                                    turns.append(("Assistant", "\n\n".join(current_gemini)))
                                    current_gemini = []
                                turns.append(("User", clean))
                elif mtype == "gemini":
                    c = data.get("content", "")
                    if c and c.strip():
                        current_gemini.append(c.strip())
            if current_gemini:
                turns.append(("Assistant", "\n\n".join(current_gemini)))
        except Exception:
            pass

    if not turns and (fallback_prompt or fallback_response):
        if fallback_prompt:
            clean = re.sub(r"<session_context>[\s\S]*?</session_context>", "", fallback_prompt).strip()
            turns.append(("User", clean or fallback_prompt))
        if fallback_response:
            turns.append(("Assistant", fallback_response.strip()))

    md = [
        f"# {title}\n",
        f"- **Session ID**: `{session_id}`",
        f"- **기록 시각**: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}\n",
    ]

    turn_num = 1
    i = 0
    while i < len(turns):
        role, text = turns[i]
        if role == "User":
            md.append(f"---\n\n## Turn {turn_num}\n\n### 👤 User\n\n{text}\n")
            if i + 1 < len(turns) and turns[i + 1][0] == "Assistant":
                md.append(f"### 🤖 Assistant\n\n{turns[i + 1][1]}\n")
                i += 1
            turn_num += 1
        elif role == "Assistant":
            md.append(f"---\n\n## Turn {turn_num} (Assistant)\n\n### 🤖 Assistant\n\n{text}\n")
            turn_num += 1
        i += 1

    return "\n".join(md)


def archive_event(payload: dict, root: Path) -> Path:
    # 세션 ID를 경로에 직접 사용하지 않아 경로 이탈과 Windows 예약 이름을 피합니다.
    session_key = sha256(payload["session_id"].encode("utf-8")).hexdigest()
    folder = root / "logs" / "gemini" / session_key
    folder.mkdir(parents=True, exist_ok=True)
    # 호출마다 고유 파일을 만들어 이전 사이클과 동시 실행 기록을 덮어쓰지 않습니다.
    record_id = uuid4().hex
    snapshot = folder / f"{record_id}.transcript.json"
    snapshot_name = None
    transcript_md_path = None
    archive_error = None

    # 대화 원본 스냅샷 및 docs/Prompt Markdown 저장
    if payload["hook_event_name"] in {"AfterAgent", "PreCompress", "SessionEnd"}:
        transcript_path = payload.get("transcript_path")
        if transcript_path:
            try:
                snapshot.write_bytes(Path(transcript_path).read_bytes())
                snapshot_name = snapshot.name
            except (OSError, KeyError) as error:
                archive_error = str(error)

        try:
            md_path = get_session_md_path(payload, root, folder)
            title = md_path.stem
            md_content = render_transcript_markdown(
                transcript_path,
                payload["session_id"],
                title,
                fallback_prompt=payload.get("prompt", ""),
                fallback_response=payload.get("prompt_response", ""),
            )
            md_path.write_text(md_content, encoding="utf-8")
            transcript_md_path = str(md_path.relative_to(root)).replace("\\", "/")
        except Exception as error:
            if not archive_error:
                archive_error = str(error)

    record = {
        "archived_at": datetime.now(timezone.utc).isoformat(),
        "event": payload,
        "transcript_snapshot": snapshot_name,
        "transcript_md": transcript_md_path,
        "archive_error": archive_error,
    }
    record_path = folder / f"{record_id}.event.json"
    record_path.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    return record_path


def main() -> int:
    # stdout은 Gemini CLI 프로토콜용 JSON만 출력하고, 오류 설명은 stderr로 보냅니다.
    try:
        payload = json.load(sys.stdin)
        record_path = archive_event(payload, Path(__file__).resolve().parents[1])
        record = json.loads(record_path.read_text(encoding="utf-8"))
        if record["archive_error"]:
            raise OSError(f"Transcript 저장 실패: {record['archive_error']}; 로그: {record_path}")
    except (OSError, ValueError, KeyError, TypeError) as error:
        message = f"세션 보관 오류: {error}"
        print(message, file=sys.stderr)
        print(json.dumps({"systemMessage": message}, ensure_ascii=False))
        # 실패를 성공으로 숨기거나 에이전트 재시도를 강제하지 않고 경고를 반환합니다.
        return 1
    output = {}
    if payload["hook_event_name"] in {"AfterAgent", "PreCompress", "SessionEnd"}:
        md_info = f" (Transcript: {record['transcript_md']})" if record.get("transcript_md") else ""
        output["systemMessage"] = f"세션 로그 및 Transcript 저장: {record_path}{md_info}"
    print(json.dumps(output, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
