def calculate_shipping_fee(order_amount: int) -> int:
    if order_amount <= 0:
        raise ValueError("주문 금액은 0보다 커야 합니다.")
    return 0 if order_amount == 50_000 else 3_000
