from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

from scripts.archive_session import archive_event


def test_archives_response_and_original_transcript(tmp_path: Path) -> None:
    transcript = tmp_path / "original.json"
    original = '{"messages": [{"text": "한글 대화"}]}'.encode("utf-8")
    transcript.write_bytes(original)
    payload = {
        "session_id": "session-1",
        "hook_event_name": "AfterAgent",
        "transcript_path": str(transcript),
        "prompt": "go",
        "prompt_response": "TC-1: Red 실패, Green 성공, 리팩터링 없음",
    }

    record_path = archive_event(payload, tmp_path)

    record = json.loads(record_path.read_text(encoding="utf-8"))
    assert record["event"] == payload
    snapshot = record_path.parent / record["transcript_snapshot"]
    assert snapshot.read_bytes() == original
    assert record["archive_error"] is None


def test_preserves_event_and_records_error_when_transcript_is_missing(tmp_path: Path) -> None:
    payload = {
        "session_id": "session-1",
        "hook_event_name": "AfterAgent",
        "transcript_path": str(tmp_path / "missing.json"),
        "prompt_response": "테스트 결과",
    }

    record_path = archive_event(payload, tmp_path)

    record = json.loads(record_path.read_text(encoding="utf-8"))
    assert record["event"] == payload
    assert record["transcript_snapshot"] is None
    assert record["archive_error"]


def test_tool_events_are_kept_separately_without_copying_transcript(tmp_path: Path) -> None:
    payload = {
        "session_id": "../session-1",
        "hook_event_name": "AfterTool",
        "tool_name": "run_shell_command",
        "tool_response": {"output": "1 failed", "exitCode": 1},
    }

    first = archive_event(payload, tmp_path)
    second = archive_event(payload, tmp_path)

    assert first != second
    assert first.is_relative_to(tmp_path / "logs" / "gemini")
    for record_path in (first, second):
        record = json.loads(record_path.read_text(encoding="utf-8"))
        assert record["event"] == payload
        assert record["transcript_snapshot"] is None
        assert record["archive_error"] is None


def test_hook_command_reports_missing_transcript_and_keeps_event(tmp_path: Path) -> None:
    # 실제 프로젝트 로그에 모의 대화가 섞이지 않도록 임시 프로젝트에서 실행합니다.
    script = tmp_path / "scripts" / "archive_session.py"
    script.parent.mkdir()
    script.write_bytes((Path(__file__).parents[1] / "scripts" / script.name).read_bytes())
    payload = {
        "session_id": "한글-session",
        "hook_event_name": "AfterAgent",
        "transcript_path": str(tmp_path / "missing.json"),
        "prompt_response": "테스트 성공",
    }

    result = subprocess.run(
        [sys.executable, "-X", "utf8", str(script)],
        input=json.dumps(payload, ensure_ascii=False),
        capture_output=True, text=True, encoding="utf-8", check=False,
    )

    assert result.returncode == 1
    assert "Transcript" in json.loads(result.stdout)["systemMessage"]
    records = list((tmp_path / "logs" / "gemini").rglob("*.event.json"))
    assert len(records) == 1
    assert json.loads(records[0].read_text(encoding="utf-8"))["event"] == payload


def test_hook_command_saves_transcript_and_prints_json_confirmation(tmp_path: Path) -> None:
    script = tmp_path / "scripts" / "archive_session.py"
    script.parent.mkdir()
    script.write_bytes((Path(__file__).parents[1] / "scripts" / script.name).read_bytes())
    transcript = tmp_path / "session.json"
    transcript.write_text('{"text": "한글 원본"}', encoding="utf-8")
    payload = {
        "session_id": "session-1", "hook_event_name": "AfterAgent",
        "transcript_path": str(transcript), "prompt_response": "Green 성공",
    }

    result = subprocess.run(
        [sys.executable, "-X", "utf8", str(script)],
        input=json.dumps(payload, ensure_ascii=False),
        capture_output=True, text=True, encoding="utf-8", check=False,
    )

    assert result.returncode == 0, result.stderr
    assert "Transcript 저장" in json.loads(result.stdout)["systemMessage"]
    snapshots = list((tmp_path / "logs" / "gemini").rglob("*.transcript.json"))
    assert len(snapshots) == 1
    assert snapshots[0].read_bytes() == transcript.read_bytes()


def test_saves_transcript_as_markdown_in_docs_prompt(tmp_path: Path) -> None:
    transcript = tmp_path / "chat.jsonl"
    lines = [
        json.dumps({"type": "user", "content": [{"text": "<session_context>설정</session_context>배송비 계산 TDD 구현해줘"}]}),
        json.dumps({"type": "gemini", "content": "TC-1 배송비 계산을 구현합니다."}),
    ]
    transcript.write_text("\n".join(lines), encoding="utf-8")
    payload = {
        "session_id": "session-shipping",
        "hook_event_name": "AfterAgent",
        "transcript_path": str(transcript),
        "prompt": "배송비 계산 TDD 구현해줘",
        "prompt_response": "TC-1 배송비 계산을 구현합니다.",
    }

    record_path = archive_event(payload, tmp_path)

    record = json.loads(record_path.read_text(encoding="utf-8"))
    assert record["transcript_md"] is not None
    md_file = tmp_path / record["transcript_md"]
    assert md_file.exists()
    date_str = datetime.now().strftime("%Y%m%d")
    assert md_file.name == f"01.배송비_계산_TDD-{date_str}.md"

    md_content = md_file.read_text(encoding="utf-8")
    assert "## Turn 1" in md_content
    assert "배송비 계산 TDD 구현해줘" in md_content
    assert "TC-1 배송비 계산을 구현합니다." in md_content
    assert "<session_context>" not in md_content


def test_subsequent_turns_update_same_markdown_file_and_keep_nn(tmp_path: Path) -> None:
    transcript = tmp_path / "chat.jsonl"
    lines = [
        json.dumps({"type": "user", "content": [{"text": "배송비 계산 작업"}]}),
        json.dumps({"type": "gemini", "content": "1단계 완료"}),
    ]
    transcript.write_text("\n".join(lines), encoding="utf-8")
    payload1 = {
        "session_id": "session-multi-turn",
        "hook_event_name": "AfterAgent",
        "transcript_path": str(transcript),
        "prompt": "배송비 계산 작업",
        "prompt_response": "1단계 완료",
    }
    archive_event(payload1, tmp_path)

    # 2번째 턴 추가
    lines.extend([
        json.dumps({"type": "user", "content": [{"text": "go"}]}),
        json.dumps({"type": "gemini", "content": "2단계 완료"}),
    ])
    transcript.write_text("\n".join(lines), encoding="utf-8")
    payload2 = {
        "session_id": "session-multi-turn",
        "hook_event_name": "AfterAgent",
        "transcript_path": str(transcript),
        "prompt": "go",
        "prompt_response": "2단계 완료",
    }
    archive_event(payload2, tmp_path)

    prompt_files = list((tmp_path / "docs" / "Prompt").glob("*.md"))
    assert len(prompt_files) == 1
    content = prompt_files[0].read_text(encoding="utf-8")
    assert "## Turn 1" in content
    assert "## Turn 2" in content
    assert "2단계 완료" in content


def test_different_session_increments_nn(tmp_path: Path) -> None:
    transcript1 = tmp_path / "chat1.jsonl"
    transcript1.write_text(json.dumps({"type": "user", "content": [{"text": "첫번째 세션"}]}), encoding="utf-8")
    archive_event({"session_id": "s1", "hook_event_name": "AfterAgent", "transcript_path": str(transcript1)}, tmp_path)

    transcript2 = tmp_path / "chat2.jsonl"
    transcript2.write_text(json.dumps({"type": "user", "content": [{"text": "두번째 세션"}]}), encoding="utf-8")
    archive_event({"session_id": "s2", "hook_event_name": "AfterAgent", "transcript_path": str(transcript2)}, tmp_path)

    prompt_files = sorted((tmp_path / "docs" / "Prompt").glob("*.md"))
    assert len(prompt_files) == 2
    assert prompt_files[0].name.startswith("01.")
    assert prompt_files[1].name.startswith("02.")


def test_topic_file_override(tmp_path: Path) -> None:
    session_id = "session-custom-topic"
    session_key = sha256(session_id.encode("utf-8")).hexdigest()
    topic_folder = tmp_path / "logs" / "gemini" / session_key
    topic_folder.mkdir(parents=True)
    (topic_folder / "topic.txt").write_text("사용자정의_주제", encoding="utf-8")

    transcript = tmp_path / "chat.jsonl"
    transcript.write_text(json.dumps({"type": "user", "content": [{"text": "내용"}]}), encoding="utf-8")
    archive_event({"session_id": session_id, "hook_event_name": "AfterAgent", "transcript_path": str(transcript)}, tmp_path)

    prompt_files = list((tmp_path / "docs" / "Prompt").glob("*.md"))
    assert len(prompt_files) == 1
    assert "사용자정의_주제" in prompt_files[0].name
