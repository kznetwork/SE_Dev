import pytest

from shipping import calculate_shipping_fee


def test_shipping_fee_is_3000_for_order_amount_10000() -> None:
    assert calculate_shipping_fee(10_000) == 3_000


def test_shipping_fee_is_zero_for_order_amount_50000() -> None:
    assert calculate_shipping_fee(50_000) == 0


def test_shipping_fee_raises_value_error_for_order_amount_minus_10000() -> None:
    with pytest.raises(ValueError):
        calculate_shipping_fee(-10_000)


def test_shipping_fee_raises_value_error_for_order_amount_minus_1() -> None:
    with pytest.raises(ValueError):
        calculate_shipping_fee(-1)


def test_shipping_fee_raises_value_error_for_order_amount_zero() -> None:
    with pytest.raises(ValueError):
        calculate_shipping_fee(0)
